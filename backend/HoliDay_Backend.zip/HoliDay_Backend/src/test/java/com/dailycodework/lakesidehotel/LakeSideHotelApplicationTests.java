package com.dailycodework.lakesidehotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LakeSideHotelApplicationTests {

    @Test
    void contextLoads() {
    }

}
